<!--
* Place: ETML
* Name: Antunes Filipe
* Project: TPI
* File: command.php
* Description: Page which is used to add the informations of the users
-->
<html>
    <?php
        // Check if the hidden input is set
        if(isset($_POST['inputHidden'])){
            // Variables to get the informations of the user (+total price)
            $inputAmount = $_SESSION['Total'];
            $inputGender = $_POST['inputGender'];
            $inputName = $_POST['inputName'];
            $inputAddress = $_POST['inputAddress'];
            $inputNum = $_POST['inputNum'];

            // Check if the form is completed
            if(isset($inputName) && isset($inputNum) && isset($inputAddress) && !empty($inputNum) && !empty($inputAddress) && !empty($inputName)){
                // Insert some sessions variables for the bill
                $_SESSION['Command'] = [$inputGender, $inputName, $inputAddress, $inputNum];
                $_SESSION['Email'] = $_POST['stripeEmail'];

                // Get the token Stripe
                $token  = $_POST['stripeToken'];

                // Informations about the customer for Stripe
                $customer = \Stripe\Customer::create(array(
                    'email' => $_POST['stripeEmail'],
                    'source'  => $token
                ));

                // Informations about the charge for Stripe
                $charge = \Stripe\Charge::create(array(
                    'customer' => $customer->id,
                    'amount'   => $inputAmount.'00', // The '00' are set because the amount on Stripe is set on cents
                    'currency' => 'chf'
                ));

                // Redirect to the paiement page
                header('Location: ../index.php?p=paiement');
            }
            else {
                // Alert the user that the form contain an error
                echo '<script> alert("Votre formulaire contient une erreur ou une cellule vide, vérifiez que les champs soient bien remplis.") </script>';
            }
        }
    ?>
    <body>
        <!-- Form for the command-->
        <form action="index.php?p=command" id="cmdForm" name='cmdForm' method="POST">
            <!-- Selects / Inputs to allow the user to enter the informations about him -->
            <h5>Votre sexe:</h5>
            <select class="input" name="inputGender">
                <option value="M">♂</option>
                <option value="F">♀</option>
            </select>
            </br>
            <h5>Votre nom complet (prénom + nom):</h5>
            <input type="text" class="input" name="inputName"/>
            </br>
            <h5>Adresse de livraison:</h5>
            <input type="text" class="input" name="inputAddress"/>
            </br>
            <h5>Votre numéro privé:</h5>
            <input type="text" class="input" name="inputNum"/>
            </br>
            </br>
            <!-- Hidden input to launch the PHP in this page -->
            <input type="hidden" name="inputHidden"/>
            <!-- Script for the paiement, shows a button and allow the user to use his credit card -->
            <script
                    src="https://checkout.stripe.com/checkout.js" id="btnStripe" class="stripe-button"
                    data-key="pk_test_NebR2ABs5VgL16Wy33qCXFu9"
                    data-name="PHPShop"
                    data-description="Boutique en ligne !"
                    data-image="php/image/shop.png"
                    data-label="Payer"
                    data-locale="auto"
                    data-zip-code="true"
                    data-currency="chf">
            </script>
        </form>
    </body>
</html>



