<!--
* Place: ETML
* Name: Antunes Filipe
* Project: TPI
* File: css.php
* Description: Define the CSS
-->
<html>
    <body>
        <style>
            /* Classes */

            .navigation{
                background-color:RGB(103, 128, 159);
                height:150px;
                width:100%;
                position:fixed;
            }

            .footer{
                background-color:RGB(103, 128, 159);
                height:150px;
                width:100%;
                font-family:"Century Gothic";
                bottom:0;
                position:fixed;
                text-align:center;
            }

            .footerText{
                font-family:"Century Gothic";
                color:white;
                margin-top:10px;
                font-size:35px;
                padding:100px;

            }

            .content{
                background-color: RGB(236, 236, 236);
                height:100%;
                padding-top:150px;
                padding-bottom:150px;
                width:100%;
                font-family:"Century Gothic";
            }

            .bar{
                padding-top:40px;
                width:1200px;
            }

            .text{
                font-family:"Century Gothic";
                color:white;
                margin-top:10px;
                font-size:30px;
            }

            .input{
                width:500px;
            }

            .basket{
                height:60px;
                width:200px;
                float:right;
                margin-top:2px;
            }

            .divSession{
                background-color:white;
                font-family:"Century Gothic";
                padding-top:5px;
                border-radius:10px;
                width:75%;
                height:55px;
                margin-left:auto;
                margin-right:auto;
                margin-top:10px;
                text-align:center;
            }

            .btnRemove{
                float:right;
                margin-right:10px;
                border-radius:10px;
                border: 2px solid white;
                margin-top:10px;
            }

            .btnAmount{
                margin-right:20px;
                border-radius:10px;
                border: 2px solid white;
                margin-top:5px;
                height: 20px;
                width:40px;
            }


            /* IDs */

            #txtThanks{
                margin-left:auto;
                margin-right:auto;
                background-color:white;
                text-align:center;
                font-family:"Century Gothic";
                font-size:20px;
                width:50%;
                border-radius:20px;
                margin-top:150px;
                padding:15px;
            }

            #form2{
                text-align:center;
            }

            #btnCommand{
                margin-top:15px;
                font-family:"Century Gothic";
                height:50px;
                width:200px;
                align-content:center;
            }

            #priceTotal{
                background-color:RGB(103, 128, 159);
                color:white;
                font-family:"Century Gothic";
                border-radius:10px;
                width:20%;
                text-align:center;
                margin-left:auto;
                margin-right:auto;
                margin-top:25px;
            }

            #btnBasket1{
                width:230px;
                margin-left:555px;
                position:absolute;
                margin-top:180px;
            }

            #btnBasket2{
                width:230px;
                position:absolute;
                margin-top:465px;
                margin-left:555px;
            }

            #basketDiv{
                float:right;
                height:60px;
                margin-right:100px;
            }

            #footerDiv{
                margin-top:50px;
            }

            #picComp1{
                float:left;
                margin-left:300px;
                height:300px;
                width:300px;
                margin-top:40px;
            }

            #picComp2{
                float:left;
                margin-top:340px;
                position:absolute;
                margin-left:300px;
                height:300px;
                width:300px;
            }

            #picText1{
                float:right;
                font-size:16px;
                height:50px;
                width:1000px;
                margin-left:40px;
                margin-top:80px;
            }

            #picText2{
                float:right;
                font-size:16px;
                height:50px;
                width:1000px;
                margin-top:120px;
            }

            #picPrice1{
                position:relative;
                float:left;
                font-size:20px;
                height:80px;
                width:100px;
                margin-left:320px;
                margin-top:50px;
            }

            #picPrice2{
                position:relative;
                float:left;
                font-size:20px;
                height:80px;
                width:100px;
                margin-top:40px;
                margin-left:920px;
            }

            #cmdForm{
                margin-top:100px;
                width:30%;
                margin-left:auto;
                margin-right:auto;
            }

            #btnForm{
                width:100%;
                height:30px;
            }
        </style>
    </body>
</html>
