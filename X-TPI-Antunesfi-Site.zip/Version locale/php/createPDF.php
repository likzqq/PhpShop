<!--
* Place: ETML
* Name: Antunes Filipe
* Project: TPI
* File: createPDF.php
* Description: This page is used to create the pdf and send it to the user
-->
<?php
        // Include sessions file
        include 'sessions.php';

        // Clean the output buffer
        ob_clean();

        // Declare informations of the client for the pdf
        $billTitle = "PhpShop - Boutique en ligne de produits informatique - 1004 Lausanne";
        $billGender = $_SESSION['Command'][0];
        $billName = $_SESSION['Command'][1];
        $billAddress = $_SESSION['Command'][2];
        $billNumber = $_SESSION['Command'][3];
        $billMail = $_SESSION['Email'];
        $arrayProducts = array();

        // Declare specs to place the elements in the pdf
        $pdfHeight = 155;
        $pdfWidth = 15;
        $pdfProduct = 75;
        $pdfPrice = 175;

        // Create the pdf
        $pdf = new fpdf();
        $pdf->AddPage();
        $pdf->SetFont('Arial'); // Font: Arial
        $pdf->SetTextColor(0,0,0); // Color: Black
        $pdf->Image('image/shop2.png', 0, 0);
        $pdf->Text(65, 27, $billTitle);
        // Write the informations about the user on the pdf
        $pdf->Text($pdfWidth, 75, $billGender);
        $pdf->Text($pdfWidth, 80, $billName);
        $pdf->Text($pdfWidth, 85, $billAddress);
        $pdf->Text($pdfWidth, 90, $billNumber);
        $pdf->Text($pdfWidth, 95, $billMail);
        $pdf->Text($pdfWidth, 150, utf8_decode("Récapitulatif de la commande: "));
        // Put the products in an array without the description
        $arrayProducts['1'] = substr(utf8_decode($Product1[0]), 0, 19);
        $arrayProducts['2'] = substr(utf8_decode($Product2[0]), 0, 19);
        $arrayProducts['3'] = substr(utf8_decode($Product3[0]), 0, 26);
        $arrayProducts['4'] = substr(utf8_decode($Product4[0]), 0, 15);
        $arrayProducts['5'] = substr(utf8_decode($Product5[0]), 0, 22);
        $arrayProducts['6'] = substr(utf8_decode($Product6[0]), 0, 20);
        $arrayProducts['7'] = substr(utf8_decode($Product7[0]), 0, 17);
        $arrayProducts['8'] = substr(utf8_decode($Product8[0]), 0, 8);

        // Increase "$h" 8 times to check which products have been chose and write the informations in the PDF
        for($h = 1; $h <= 8; $h++){
            if(${'Product' . $h}[0] != Array() && !empty(${'Product' . $h}[0])){
                $pdf->Text($pdfWidth, $pdfHeight, "1x");
                $pdf->Text($pdfProduct, $pdfHeight, $arrayProducts[$h]);
                $pdf->Text($pdfPrice, $pdfHeight, "Prix: ". ${'Price' . $h}[0] .".-");
                $pdfHeight = $pdfHeight + 5;
            }
        }
/*
        // Check if the first product is an array or is empty (Enter if the client chose this product)
        if($Product1[0] != Array() && !empty($Product1[0])){

            // Add some text, the price and the product on the pdf


        }
        // Check if the second product is an array or is empty (Enter if the client chose this product)
        if($Product2[0] != Array() && !empty($Product2[0])){
            // Put the second product in an array

            // Add some text, the price and the product on the pdf
            $pdf->Text($pdfAmount, $pdfHeight, "1x");
            $pdf->Text($pdfProduct, $pdfHeight, $arrayProducts['2']);
            $pdf->Text($pdfPrice, $pdfHeight, "Prix: ". $Price2[0] .".-");
            $pdfHeight = $pdfHeight + 5;
        }
        // Check if the third product is an array or is empty (Enter if the client chose this product)
        if($Product3[0] != Array() && !empty($Product3[0])){
            // Put the third product in an array

            // Add some text, the price and the product on the pdf
            $pdf->Text($pdfAmount, $pdfHeight, "1x");
            $pdf->Text($pdfProduct, $pdfHeight, $arrayProducts['3']);
            $pdf->Text($pdfPrice, $pdfHeight, "Prix: ". $Price3[0] .".-");
            $pdfHeight = $pdfHeight + 5;
        }
        // Check if the fourth product is an array or is empty (Enter if the client chose this product)
        if($Product4[0] != Array() && !empty($Product4[0])){
            // Put the fourth product in an array

            // Add some text, the price and the product on the pdf
            $pdf->Text($pdfAmount, $pdfHeight, "1x");
            $pdf->Text($pdfProduct, $pdfHeight, $arrayProducts['4']);
            $pdf->Text($pdfPrice, $pdfHeight, "Prix: ". $Price4[0] .".-");
            $pdfHeight = $pdfHeight + 5;
        }
        // Check if the fifth product is an array or is empty (Enter if the client chose this product)
        if($Product5[0] != Array() && !empty($Product5[0])){
            // Put the fifth product in an array

            // Add some text, the price and the product on the pdf
            $pdf->Text($pdfAmount, $pdfHeight, "1x");
            $pdf->Text($pdfProduct, $pdfHeight, $arrayProducts['5']);
            $pdf->Text($pdfPrice, $pdfHeight, "Prix: ". $Price5[0] .".-");
            $pdfHeight = $pdfHeight + 5;
        }
        // Check if the sixth product is an array or is empty (Enter if the client chose this product)
        if($Product6[0] != Array() && !empty($Product6[0])){
            // Put the sixth product in an array

            // Add some text, the price and the product on the pdf
            $pdf->Text($pdfAmount, $pdfHeight, "1x");
            $pdf->Text($pdfProduct, $pdfHeight, $arrayProducts['6']);
            $pdf->Text($pdfPrice, $pdfHeight, "Prix: ". $Price6[0] .".-");
            $pdfHeight = $pdfHeight + 5;
        }
        // Check if the seventh product is an array or is empty (Enter if the client chose this product)
        if($Product7[0] != Array() && !empty($Product7[0])){
            // Put the seventh product in an array

            // Add some text, the price and the product on the pdf
            $pdf->Text($pdfAmount, $pdfHeight, "1x");
            $pdf->Text($pdfProduct, $pdfHeight, $arrayProducts['7']);
            $pdf->Text($pdfPrice, $pdfHeight, "Prix: ". $Price7[0] .".-");
            $pdfHeight = $pdfHeight + 5;
        }
        // Check if the eighth product is an array or is empty (Enter if the client chose this product)
        if($Product8[0] != Array() && !empty($Product8[0])){
            // Put the eighth product in an array

            // Add some text, the price and the product on the pdf
            $pdf->Text($pdfAmount, $pdfHeight, "1x");
            $pdf->Text($pdfProduct, $pdfHeight, $arrayProducts['8']);
            $pdf->Text($pdfPrice, $pdfHeight, "Prix: ". $Price8[0] .".-");
            $pdfHeight = $pdfHeight + 5;
        }*/
        // Add total price in the pdf
        $pdf->Text($pdfWidth, $pdfHeight + 5, "Prix total de la commande: ". $_SESSION['Total'] .".-");
        // Add text to say thank you
        $pdf->Text(30, 280, utf8_decode("Nous vous remercions de nous avoir choisi et espérons vous revoir très vite !"));
        // Output the pdf in download for the user and stock it on the machine
        $pdf->Output('D', 'facture.pdf');

    ?>