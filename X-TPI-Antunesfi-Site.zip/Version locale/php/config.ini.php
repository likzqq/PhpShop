<!--
* Place: ETML
* Name: Antunes Filipe
* Project: TPI
* File: config.ini.php
* Description: This page shows the config file, used to declare what I need in the whole project
-->
<html>
    <head>
        <?php
            // Don't display the errors to avoid the warnings on the cart and to protect if a hacker tries something
            error_reporting(E_ALL & ~E_NOTICE & ~E_WARNING);
            // Start the session
            session_start();
            // Start the output buffer
            ob_start();
            // Set the timezone
            date_default_timezone_set('Europe/Stockholm');

            $i = 0;

            // Include PHPExcel library
            include 'PHPExcel/Classes/PHPExcel/IOFactory.php';
            include 'PHPExcel/Classes/PHPExcel.php';
            include 'PHPExcel/Classes/PHPExcel/Reader/Excel2007.php';
            // Include fpdf library
            include 'fpdf/fpdf.php';
            // Include Stripe
            include 'stripePHP/init.php';
            // Include the CSS
            include 'css/css.php';
            // Initiate cURL
            $curl = curl_init();

            // Keys in a array for stripe
            $stripe = array(
                "secret_key"      => "sk_test_0R1EztMZbc8N9iLXJDgj3Y0X",
                "publishable_key" => "pk_test_NebR2ABs5VgL16Wy33qCXFu9"
            );

            // Set the secret key
            \Stripe\Stripe::setApiKey($stripe['secret_key']);

            // Properties (Declare variables and the db)
            $user = "root";
            $bd = new PDO('mysql:host=localhost;dbname=boutique;charset=utf8', $user, $user);

        ?>

        <!-- Set UTF8 -->
        <meta charset="utf-8">

        <!-- Define initial scale -->
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <!-- Latest compiled and minified CSS - Bootstrap -->
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">

        <!-- jQuery library for Bootstrap -->
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>

        <!-- Latest compiled JavaScript for Bootstrap -->
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

    </head>
</html>



