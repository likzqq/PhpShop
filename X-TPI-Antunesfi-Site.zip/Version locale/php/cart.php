<!--
* Place: ETML
* Name: Antunes Filipe
* Project: TPI
* File: cart.php
* Description: This page show the cart and allow to delete products of it
-->
<html>
    <head>
        <?php
            // Include sessions file
            include 'sessions.php';

            // Initiate the total price
            $priceTotal = 0;

            // Create a form to recup' the post of the buttons
            echo "<form action='#' method='POST'>";

            // Check if no products have been choose
            if($Product1[0] == Array() && $Product2[0] == Array() && $Product3[0] == Array() && $Product4[0] == Array() && $Product5[0] == Array() && $Product6[0] == Array() && $Product7[0] == Array() && $Product8[0] == Array()) {
                echo "<div class='divSession'>Vous n'avez rien choisi, veuillez retourner à la boutique!</div>";
            }
            else {
                // Increase "$z" to do this 8 times (8 products in the shop)
                for ($z = 1; $z <= 8; $z++) {
                    if (${'Product' . $z} != Array()) {
                        // Create the divs which contains the informations about the product and a button to delete from the cart if wanted
                        echo "<div class='divSession'> " . ${'Product' . $z}[0] . " 
                        <input type='submit' class='btnRemove' name='btnRemove" . $z . "' value='x'> 
                        </br> Prix: " . ${'Price' . $z}[0] . ".- francs suisse
                        </div>";
                        // Increase the total price
                        $priceTotal = $priceTotal + ${'Price' . $z}[0];
                    }

                    // Check if the button is set (is clicked)
                    if (isset($_POST['btnRemove' . $z])) {
                        // Set this session variable to an array (delete from the list)
                        $_SESSION['Product'][$z] = Array();
                        // Refresh
                        header('Location: ../index.php?p=cart');
                    }
                }
            }
            /*
                for($y = 1; $y <= 8; $y++){
                    // Check if the button is set (is clicked)
                    if (isset($_POST['btnRemove' . $y])) {
                        // Unset the session
                        $_SESSION['Product'][$y] = Array();
                        // Refresh
                        header('Location: ../index.php?p=cart');
                    }
                } */
            /*
                // Check if the first product is chose
                if ($Product1[0] != Array()) {
                    // Create a div which contains the informations about the product and a button to delete from the cart if wanted
                    echo "<div class='divSession'>$Product1[0] <input type='submit' class='btnRemove' name='btnRemove1' value='x'> </br> Prix:  $Price1[0].- francs suisse</div>";
                    // Increase the total price
                    $priceTotal = $priceTotal + $Price1[0];
                }
                // Check if the second product is chose
                if ($Product2[0] != Array()) {
                    // Create a div which contains the informations about the product and a button to delete from the cart if wanted
                    echo "<div class='divSession'>$Product2[0] <input type='submit' class='btnRemove' name='btnRemove2' value='x'> </br> Prix:  $Price2[0].- francs suisse</div>";
                    // Increase the total price
                    $priceTotal = $priceTotal + $Price2[0];
                }
                // Check if the third product is chose
                if ($Product3[0] != Array()) {
                    // Create a div which contains the informations about the product and a button to delete from the cart if wanted
                    echo "<div class='divSession'>$Product3[0] <input type='submit' class='btnRemove' name='btnRemove3' value='x'> </br> Prix:  $Price3[0].- francs suisse</div>";
                    // Increase the total price
                    $priceTotal = $priceTotal + $Price3[0];
                }
                // Check if the fourth product is chose
                if ($Product4[0] != Array()) {
                    // Create a div which contains the informations about the product and a button to delete from the cart if wanted
                    echo "<div class='divSession'>$Product4[0] <input type='submit' class='btnRemove' name='btnRemove4' value='x'> </br> Prix:  $Price4[0].- francs suisse</div>";
                    // Increase the total price
                    $priceTotal = $priceTotal + $Price4[0];
                }
                // Check if the fifth product is chose
                if ($Product5[0] != Array()) {
                    // Create a div which contains the informations about the product and a button to delete from the cart if wanted
                    echo "<div class='divSession'>$Product5[0] <input type='submit' class='btnRemove' name='btnRemove5' value='x'> </br> Prix:  $Price5[0].- francs suisse</div>";
                    // Increase the total price
                    $priceTotal = $priceTotal + $Price5[0];
                }
                // Check if the sixth product is chose
                if ($Product6[0] != Array()) {
                    // Create a div which contains the informations about the product and a button to delete from the cart if wanted
                    echo "<div class='divSession'>$Product6[0] <input type='submit' class='btnRemove' name='btnRemove6' value='x'> </br> Prix:  $Price6[0].- francs suisse</div>";
                    // Increase the total price
                    $priceTotal = $priceTotal + $Price6[0];
                }
                // Check if the seventh product is chose
                if ($Product7[0] != Array()) {
                    // Create a div which contains the informations about the product and a button to delete from the cart if wanted
                    echo "<div class='divSession'>$Product7[0] <input type='submit' class='btnRemove' name='btnRemove7' value='x'> </br> Prix:  $Price7[0].- francs suisse</div>";
                    // Increase the total price
                    $priceTotal = $priceTotal + $Price7[0];
                }
                // Check if the eighth product is chose
                if ($Product8[0] != Array()) {
                    // Create a div which contains the informations about the product and a button to delete from the cart if wanted
                    echo "<div class='divSession'>$Product8[0] <input type='submit' class='btnRemove' name='btnRemove8' value='x'> </br> Prix:  $Price8[0].- francs suisse</div>";
                    // Increase the total price
                    $priceTotal = $priceTotal + $Price8[0];
                } */
            // If the total price isn't 0
            if($priceTotal != 0){
                // Show the total price
                echo "<p id='priceTotal'>Total: $priceTotal.- francs suisse (TVA comprise)</p>";
            }
        echo "</form>"
        ?>

        <!-- Form for the button that redirect on the command page -->
        <form method='post' id='form2' action='../index.php?p=command'>

            <?php
                // if the total price isn't 0
                if($priceTotal != 0)
                {
                    // Button "Commander"
                    echo "<input type='submit' id='btnCommand' name='btnCommand' value='Commander'>";
                    // Put the total price in a session variable
                    $_SESSION['Total'] = $priceTotal;
                }
            ?>
        </form>

    </head>
</html>



