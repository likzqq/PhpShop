<!--
* Place: ETML
* Name: Antunes Filipe
* Project: TPI
* File: index.php
* Description: First page where the other pages are include
-->

<html>
    <head>
        <!-- Include the configuration file -->
        <?php include 'php/config.ini.php'; ?>
    </head>

    <body>
        <header>
            <!-- Include header and footer -->
            <?php include 'php/header.php'; ?>
            <?php include 'php/footer.php'; ?>
        </header>

        <!-- Include all the pages in the content to keep the header/footer in all the pages -->
        <div class="content">
            <?php
                if(isset($_GET['p']) AND $_GET['p'] == "gpu"){ // if the gpu's page is called -> call it
                    include 'php/gpu.php';
                }
                if(isset($_GET['p']) AND $_GET['p'] == "motherboard"){ // if the motherboard's page is called -> call it
                    include 'php/motherboard.php';
                }
                if(isset($_GET['p']) AND $_GET['p'] == "disk"){ // if the disk's page is called -> call it
                    include 'php/disk.php';
                }
                if(isset($_GET['p']) AND $_GET['p'] == "process" OR $_SERVER['REQUEST_URI'] == "/" ){ // if the process's page is called or if that's the very first page (the default page is process.php) -> call it
                    include 'php/process.php';
                }
                if(isset($_GET['p']) AND $_GET['p'] == "cart") { // if the basket page is called -> call it
                    include 'php/cart.php';
                }
                if(isset($_GET['p']) AND $_GET['p'] == "command") { // if the command page is called -> call it
                    include 'php/command.php';
                }
                if(isset($_GET['p']) AND $_GET['p'] == "paiement") { // if the paiement page is called -> call it
                    include 'php/paiement.php';
                }
            ?>
        </div>
    </body>
</html>



